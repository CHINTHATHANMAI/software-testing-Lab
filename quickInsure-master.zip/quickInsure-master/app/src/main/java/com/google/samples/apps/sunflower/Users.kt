package com.google.samples.apps.sunflower
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

class Users {
    //var id: Int = 0
    //var login: String? = null
    var product_code: String? = null
    var product_name: String? = null
    var description: String? = null
}